<img src="assets/lavlue.svg"  />

<hr>

- **개요** : socket.io와 Vue.js로 구현한 채팅 서비스
- **기간** : 2021.12.22 ~ 2021.12.23
- [**회고**](https://hing9u.tistory.com/91)

<br/>



```bash
$ cd backend
$ npm install
$ npm run start
```

```bash
$ cd frontend
$ npm install
$ npm run serve
```



<br/>



![](https://i.imgur.com/LlMPD8X.png)

![](assets/image.webp)
