const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const port = process.env.PORT || 3000; /// http 서버가 포트 3000에서 수신 대기


app.get('/', (req, res) => { // 웹 사이트 홈에 도달했을 때 호출 되는 경로 핸들러를 정의
  res.sendFile(__dirname + '/index.html');
});

// 모든 사람에게 이벤트를 보내기 위해 io.emit() 사용
io.on('connection', (socket) => {
  console.log('a user connected...') // 유저 한명 연결될 때 마다 출력
  socket.on('chat message', msg => {
    io.emit('chat message', msg);
  });
});

http.listen(port, () => {
  console.log(`Socket.IO server running at http://localhost:${port}/`);
});
