package com.mycom.myapp.code.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
// @AllArgsConstructor
// @NoArgsConstructor
@ToString
public class CodeParamDto {

}
