<template>
	<div>
		<h1>NOT FOUND !!</h1>
	</div>
</template>

<script>
	export default {};
</script>

<style></style>
